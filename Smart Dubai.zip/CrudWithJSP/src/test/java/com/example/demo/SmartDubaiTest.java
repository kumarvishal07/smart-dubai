package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.smart.demo.SmartDubaiApplication;
import com.smart.demo.dao.BookRepo;
import com.smart.demo.entity.Book;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = SmartDubaiApplication.class)
public class SmartDubaiTest {
	@Mock
	private BookRepo repo;

	@Autowired
	private BookRepo repo1;

	@Test
	public void testGetAllBooks() throws Exception {
		Book book = getBook();
		List<Book> books = new ArrayList<>();
		books.add(book);
		given(repo.findAll()).willReturn(books);
		List<Book> result = repo.findAll();
		assertEquals(result.size(), 1);
	}

	@Test
	public void testGetEmployee() throws Exception {
		System.out.println(this.repo);
		System.out.println(this.repo1);
		Book book = getBook();
		given(repo.findByISBN(book.getISBN())).willReturn(book);
		Book result = repo.findById(1).get();
		assertEquals(result.getBid(), 1);
	}

	@Test
	public void testDeleteBook() throws Exception {
		doNothing().when(repo).deleteById(1);
		repo.deleteById(1);
		assertTrue(true);
	}

	@Test
	public void testSaveOrUpdateBook() throws Exception {
		Book book = getBook();
		doNothing().when(repo).save(book);
		repo.save(book);
		assertTrue(true);
	}

	private Book getBook() {
		Book book = new Book();
		book.setAuthor("Visihal");
		book.setDescription("test");
		book.setISBN("wd8ye23");
		book.setName("poem");
		book.setPrice(765.43);
		book.setType("test");
		return book;
	}
}
