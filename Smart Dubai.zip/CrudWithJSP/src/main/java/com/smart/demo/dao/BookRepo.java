package com.smart.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smart.demo.entity.Book;

@Repository
public interface BookRepo extends JpaRepository<Book, Integer>{
	
	@Query(value="select * from book where name = ?1",nativeQuery=true)
	List<Book> findByName(String name);
	
	@Query(value="select * from book where isbn = ?1",nativeQuery=true)
	Book findByISBN(String isbn);
	
	@Query(value = "select sum(price) from book where isbn in ?1", nativeQuery = true)
	double findPriceByISBN(List<String> isbns);
	


}
