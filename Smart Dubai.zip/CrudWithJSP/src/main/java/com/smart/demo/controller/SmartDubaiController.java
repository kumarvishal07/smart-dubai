package com.smart.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.smart.demo.dao.BookRepo;
import com.smart.demo.entity.Book;
import com.smart.demo.exception.NoBookFoundException;

@Controller
public class SmartDubaiController {

	@Autowired
	BookRepo repo;

	@RequestMapping("/")
	public String home() {
		System.out.println("Project is started...");
		return "home.jsp";
	}

	@PostMapping("/addBook")
	public ResponseEntity<Book> addBook(@RequestBody Book book) {
		System.out.println("addBook" + book);
		Book savedBook = repo.save(book);
		if (savedBook == null) {
			// throw new ServerException();
			return new ResponseEntity<>(savedBook, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>(savedBook, HttpStatus.CREATED);
		}
	}

	@RequestMapping("/getBooks")
	public ResponseEntity<List<Book>> getBooks() {
		return new ResponseEntity<>(repo.findAll(), HttpStatus.OK);
	}

	@RequestMapping("/getBookByName")
	public ResponseEntity<List<Book>> getBookByName(@RequestParam String name) throws Exception {
		List<Book> books = repo.findByName(name);
		if (books.size() > 0) {
			return new ResponseEntity<>(books, HttpStatus.OK);
		} else {
			throw new NoBookFoundException();
		}
	}

	@RequestMapping("/getBookByISBN")
	public ResponseEntity<Book> getBookByISBN(@RequestParam String isbn) throws Exception {
		Book books = repo.findByISBN(isbn);
		if (books != null) {
			return new ResponseEntity<>(books, HttpStatus.OK);
		} else {
			throw new NoBookFoundException();
		}
	}

	@DeleteMapping("/deleteBook")
	@ResponseBody
	public ResponseEntity deleteBook(@RequestParam String isbn) {
		Book book = repo.findByISBN(isbn);
		repo.deleteById(book.getBid());
		return new ResponseEntity<>("Book is deleted with isdb " + isbn, HttpStatus.OK);

	}

	// update the price, description , type
	@PutMapping("/updateBook")
	@ResponseBody
	public ResponseEntity<Book> updateBook(@RequestBody Book book) {
		Book findBook = repo.findByISBN(book.getISBN());
		if(findBook != null) {
		findBook.setDescription(book.getDescription());
		findBook.setPrice(book.getPrice());
		findBook.setType(book.getType());
		Book books = repo.save(findBook);
		return new ResponseEntity<>(books, HttpStatus.OK);
		}
		else throw new NoBookFoundException();

	}

	@GetMapping("/checkout")
	public ResponseEntity checkOut(@RequestParam List<String> ids, @RequestParam double discount) {
		try {
			double price = repo.findPriceByISBN(ids);
			double totalPrice = price - price * discount / 100;
			return new ResponseEntity<>("Total prices are " + totalPrice, HttpStatus.OK);
		} catch (Exception e) {
			throw new NoBookFoundException();
		}
	}
}
