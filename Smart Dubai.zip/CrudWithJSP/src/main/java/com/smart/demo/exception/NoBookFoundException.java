package com.smart.demo.exception;

public class NoBookFoundException extends RuntimeException{

	private static final long servialVersion = 1L;
}
