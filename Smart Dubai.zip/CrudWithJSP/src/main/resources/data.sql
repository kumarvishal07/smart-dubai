create table book (id int, name varchar(20),description varchar(20),author varchar(20)
,type varchar(20),price varchar(20),ISBN varchar(20));
insert into book values(0001, 'java','java - 8','vishal','pdf',500.5,'273645BSP');